document.addEventListener("DOMContentLoaded", () => {
    var map = L.map('map').setView([-6.2, 106.816666], 13); // Koordinat Jakarta

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    L.marker([-6.2, 106.816666]).addTo(map)
        .bindPopup('Lokasi Toko Ajesgo')
        .openPopup();

    document.getElementById("orderForm").addEventListener("submit", function(e) {
        e.preventDefault();
        alert("Pesanan Anda berhasil dikirim!");
    });
});
